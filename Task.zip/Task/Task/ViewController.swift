//
//  ViewController.swift
//  Task
//
//  Created by prominere on 09/09/20.
//  Copyright © 2020 Prominere. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage


class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var refreshControl = UIRefreshControl()

    var tableArray: NSMutableArray = [];
    @IBOutlet var tableView: UITableView?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        self.refreshControl.addTarget(self, action: #selector(refreshData), for: UIControl.Event.valueChanged)
           self.tableView?.addSubview(refreshControl)
        self.getData()
        // Do any additional setup after loading the view.
    }
    @objc func refreshData() {
      self.getData()
        self.refreshControl.endRefreshing()
    }
    //api calling
    func getData()
    {
       
              var request = API.getURLRequest()
            request.httpBody = try! JSONSerialization.data(withJSONObject: [], options: [])
                      AF.request(request as URLRequestConvertible).responseJSON {
                          response in
                          do
                          {
                            if(response.data != nil)
                            {
                            let jsonResponse = try JSONSerialization.jsonObject(with: response.data!, options: .mutableContainers) as! NSMutableArray
                            print(jsonResponse)
                            self.tableArray = jsonResponse
                            self.tableView!.dataSource = self
                            self.tableView!.delegate = self
                            self.tableView!.reloadData()
                            }
                          }
                          catch let error{
                              print(error)
                          }
                        
                      }
    }

}
extension ViewController {
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as! TableViewCell
        let result = self.tableArray[indexPath.row] as! NSDictionary
        
        cell.name?.text = (result["name"] as! String)
        cell.realname?.text = (result["realname"] as! String)
        cell.team?.text = (result["team"] as! String)
        cell.imgView!.sd_setImage(with: URL(string:(result["imageurl"] as? String)!))
       cell.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        UIView.animate(withDuration: 0.4) {
            cell.transform = CGAffineTransform.identity
        }
        return cell
    }
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.tableArray.count
        
    }
    
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(self.tableArray[indexPath.row])
        tableView.deselectRow(at: indexPath, animated: true)
    }
    internal func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {

        let contextItem = UIContextualAction(style: .destructive, title: "Delete") {  (contextualAction, view, boolValue) in

             self.tableArray.removeObject(at: indexPath.row)
             self.tableView!.reloadData()
        }
        let swipeActions = UISwipeActionsConfiguration(actions: [contextItem])
        return swipeActions
    }
    
      func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        cell.layer.transform = CATransform3DMakeScale(0.1,0.1,1)
        UIView.animate(withDuration: 0.3, animations: {
            cell.layer.transform = CATransform3DMakeScale(1,1,1)
        })
        UIView.animate(withDuration: 1, animations: {
            cell.layer.transform = CATransform3DMakeScale(2,2,2)
        })
        UIView.animate(withDuration: 0.3, animations: {
            cell.layer.transform = CATransform3DMakeScale(1,1,1)
        })

    }
   
}

