//
//  TableViewCell.swift
//  Task
//
//  Created by prominere on 09/09/20.
//  Copyright © 2020 Prominere. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    
    @IBOutlet var imgView: UIImageView?
    @IBOutlet var name: UILabel?
    @IBOutlet var realname: UILabel?
    @IBOutlet var team: UILabel?
    @IBOutlet var bgView: UIView?

    override func awakeFromNib() {
        super.awakeFromNib()
            self.bgView?.layer.cornerRadius = 3.0
           self.bgView?.layer.shadowColor = UIColor.gray.cgColor
           self.bgView?.layer.shadowOffset = CGSize(width: 0, height: 0)
           self.bgView?.layer.shadowRadius = 1.0
           self.bgView?.layer.shadowOpacity = 0.3
           self.bgView?.layer.borderColor = UIColor.lightGray.cgColor
           self.bgView?.layer.borderWidth = 1.0
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
