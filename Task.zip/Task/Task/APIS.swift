
//  APIS.swift
//   Task
//  Created by prominere on 09/09/20.
//  Copyright © 2020 Prominere. All rights reserved.

import UIKit

class APIS: NSObject {
   
}
struct GET_API {
    
    //SignUp & SignIn
    var Sign_UP_API = "\(Domain_Name)/api/register"
    
    func getURLRequest() -> URLRequest
    {
        let targetURL = URL(string: "https://simplifiedcoding.net/demos/marvel/")
        var request = URLRequest(url: targetURL!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("CODEX@123",forHTTPHeaderField: "x-api-key")
        return request
    }
    
}
var Domain_Name = "http://pigeon.demoservershosting.com" // Production
var API = GET_API()
